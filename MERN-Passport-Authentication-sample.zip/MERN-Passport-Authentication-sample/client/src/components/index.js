import Login from "./Login";
import Register from "./Register";
import Home from "./Home";

import "./Auth.css";

export { Login, Register, Home };
