## Available Scripts

In the project directory, you can run:

### `npm run dev`

Runs the app in the development mode.
